# Common template for Helm Applications

The scope of this chart is to externalize helm charts from the applications since Kubernetes changes and we cannot modify each time all the repositories to make the alignment procedures.

For this reason, we are going to create a library chart which allows us to simplify the process of aligning our applications.
- sidecars for messages
- init containers to execute preparatory tasks
- jobs (TBD)
- cronjobs (TBD)
- network policies
- service account
- general rbac configurations
- statefulset (TBD)
- deployment
- secrets (TBD)

Note that this library already includes the chart we already used for messaging sidecars and supports it and their configuration as well.
  
- [Common template for Helm Applications](#common-template-for-helm-applications)
- [Add a new resource](#add-a-new-resource)
  - [Example of usage](#example-of-usage)
- [Build](#build)
- [Test](#test)
- [Configure](#configure)
    - [Init Containers and Messaging Sidecars](#init-containers-and-messaging-sidecars)

# Add a new resource

In order to add a brand new resource to the library, you need to:
- modify `/templates/_main.tpl` to call the new defined template
  ```gotpl
  {{- if .Values.mynewresource.create }}
  {{ include "common-template.mynewresource" . }}
  ---
  {{- end}}
  ```
- create a new `/templates/_mynewresource.tpl` template, which will contain your gotpl code
  ```gotpl
  {{- define "common-template.mynewresource" -}}
  ### YOUR GOTPL CODE HERE
  {{- end }}
  ```
once you have defined your resource, in order to test, write your own values.yaml under the `tests/testing-template` folder and follow the instructions defined [here](#test)
## Example of usage

At the moment each application in our repository contains an `helm` folder that allows us to manipulate and generate the helm chart needed for that application.
Generally speaking this is not needed since it needs to have all the resources declared within it but, rather, declare what are the needs of that application and allows it to explicit their configuration.

For this reason the helm chart provided within this repository creates a `helm library` which renders a specific configuration based on values passed (which simplifies also the override of some behaviours from the deployment)

```
helm create my-brand-new-project

cd my-brand-new-project

rm templates/*

cat <<EOF
dependencies:
- name: common-template
  version: 0.0.1
  repository: https://helmdigitalus.azurecr.io/helm/v1/repo/
EOF >> Chart.yaml

echo '{{ include "common-template.main" . }}' > templates/main.yaml

cat << EOF
deployment:
  enabled: false
autoscaling:
  enabled: false
ingress:
  enabled: false
service:
  enabled: false
serviceAccount:
  enabled: false
configmap:
  enabled: false
networkPolicy:
  enabled: false
rbac:
  local:
    enabled: false
  cluster:
    enabled: false
database:
  create: false
EOF >> values.yaml

helm template .
```

At this point you should have an empty output since everithing has been disabled.

Of course, the aforementioned instructions does not forbid you from creating your own resources. more information about the available resources are listed at  [Configure](#Configure)

# Build

from the root folder

```bash
helm package .
```

# Test

In order to test your templates, you need to create a new helm chart which integrates your library chart. 
Inside the test folder there is an example chart with multiple values file to test the different configuration of your deployments:

```bash
cd tests/testing-template
helm dependency update
helm template . --values <values.yaml> --debug
```
if you have a kubernetes cluster to run against, you can also add the `--validate` param, so that your output get validate also against resources defined in your cluster

how to test all together:
```bash
cd <project_root>
./tests/test.sh
```

Sample output
```bash
Hang tight while we grab the latest from your chart repositories...
...Successfully got an update from the "ingress-nginx" chart repository
...Successfully got an update from the "digitalus" chart repository
...Successfully got an update from the "bitnami" chart repository
Update Complete. ⎈Happy Helming!⎈
Saving 2 charts
Downloading sp-sidecar-templates from repo https://helmdigitalus.azurecr.io/helm/v1/repo/
Deleting outdated charts
execute values-database-explicit-name.yaml
values-database-explicit-name.yaml exit: 0
execute values-deployment-real.yaml
values-deployment-real.yaml exit: 0
execute values-empty.yaml
values-empty.yaml exit: 0
execute values-full.yaml
values-full.yaml exit: 0
execute values-only-deployment.yaml
values-only-deployment.yaml exit: 0
execute values-sidecars-init.yaml
values-sidecars-init.yaml exit: 0
```
# Configure

There is a full example under [/tests/testing-template/values-full.yaml](/tests/testing-template/values-full.yaml) that will help you understand all possible configuration parameters
Moreover there is one focused on Deployments under [/tests/testing-template/values-only-deployment.yaml](/tests/testing-template/values-only-deployment.yaml) 

### Init Containers and Messaging Sidecars
there is a full example under [/tests/testing-template/values-sidecars-init.yaml](/tests/testing-template/values-sidecars-init.yaml) that will help you understand all possible configuration parameters
