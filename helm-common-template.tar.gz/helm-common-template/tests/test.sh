#!/bin/bash

current_dir=$(pwd)
cd testing-template
helm dependency update;
for f in values-*; do
  echo "execute $f"; 
  exit=$(helm template --values=$f --validate . > /dev/null); 
  echo "$f exit: $?"; 
done;
cd $current_dir